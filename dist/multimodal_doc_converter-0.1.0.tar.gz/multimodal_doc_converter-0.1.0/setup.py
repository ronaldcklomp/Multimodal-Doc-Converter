from setuptools import setup, find_packages  # type: ignore

setup(
    name="multimodal-doc-converter",
    version="0.1.0",
    description="Local multimodal RAG document converter (PDF -> images + raw text)",
    author="Ronald",
    author_email="ronald@kurp.nl",
    python_requires=">=3.11",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "typer>=0.12.0",
        "pydantic>=2.7.0",
        "pymupdf>=1.24.0",
        "Pillow>=10.0.0",
        "pytesseract>=0.3.10",
        "surya-ocr==0.17.0"
    ],
    entry_points={
        "console_scripts": [
            "mmrag-convert=mmrag_converter.cli:app",
        ],
    },
)
